Font: Shakerato
Created By: Fikri F Hasan - Vilova
E-Mail: ffhasan89@gmail.com

This license is for the personal usage/free usage only of font files downloaded from Fikri F Hasan - Vilova; you are not purchasing/licensing the copyright to the design of the fonts, you may not sublicense, sell, lease, or give away the fonts.

This is an agreement between you, the purchaser, and Fikri F Hasan - Vilova. By downloading you acknowledge your understanding and promise to comply with its terms.

If you are interested in the commercial use of this/these font(s) or using this/these font(s) in any manner outside the realm of "personal use," you can contact me at email: ffhasan89@gmail.com.

Thank you for being supportive,
Fikri F Hasan - Vilova